'use strict';
(() => {
  // ───────────── أدوات صغيرة ─────────────
  const $ = (sel, root = document) => root.querySelector(sel);
  const $$ = (sel, root = document) => [...root.querySelectorAll(sel)];

  /** ينشئ عنصر DOM بأمان (لا نستخدم innerHTML مع بيانات المستخدمين أبدًا). */
  function h(tag, attrs, ...kids) {
    const el = document.createElement(tag);
    for (const [k, v] of Object.entries(attrs || {})) {
      if (v === null || v === undefined || v === false) continue;
      if (k === 'class') el.className = v;
      else if (k.startsWith('on') && typeof v === 'function') el.addEventListener(k.slice(2), v);
      else if (v === true) el.setAttribute(k, '');
      else el.setAttribute(k, v);
    }
    for (const kid of kids.flat(Infinity)) {
      if (kid === null || kid === undefined || kid === false) continue;
      el.append(kid instanceof Node ? kid : document.createTextNode(String(kid)));
    }
    return el;
  }

  const ICONS = {
    close: '<path d="M18 6 6 18M6 6l12 12"/>',
    check: '<path d="M20 6 9 17l-5-5"/>',
    logout: '<path d="M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4"/><path d="m16 17 5-5-5-5"/><path d="M21 12H9"/>',
    trash: '<path d="M3 6h18"/><path d="M8 6V4a1 1 0 0 1 1-1h6a1 1 0 0 1 1 1v2"/><path d="m19 6-1 14a2 2 0 0 1-2 2H8a2 2 0 0 1-2-2L5 6"/>',
    edit: '<path d="M12 20h9"/><path d="M16.5 3.5a2.1 2.1 0 0 1 3 3L7 19l-4 1 1-4Z"/>',
    eye: '<path d="M2 12s3.5-7 10-7 10 7 10 7-3.5 7-10 7S2 12 2 12Z"/><circle cx="12" cy="12" r="3"/>',
    eyeOff: '<path d="M17.9 17.9A10.9 10.9 0 0 1 12 19c-6.5 0-10-7-10-7a18 18 0 0 1 5-5.9"/><path d="M9.9 4.2A9.7 9.7 0 0 1 12 4c6.5 0 10 7 10 7a18 18 0 0 1-2.2 3.2"/><path d="m2 2 20 20"/>',
    chevR: '<path d="m9 18 6-6-6-6"/>',
    chevL: '<path d="m15 18-6-6 6-6"/>',
    gamepad: '<path d="M6 12h4M8 10v4"/><circle cx="15" cy="13" r="1"/><circle cx="18" cy="11" r="1"/><path d="M17.3 5H6.7a4 4 0 0 0-3.9 3.2L1.4 15a3 3 0 0 0 5.2 2.4L8 16h8l1.4 1.4a3 3 0 0 0 5.2-2.4l-1.4-6.8A4 4 0 0 0 17.3 5Z"/>',
    dashboard: '<rect x="3" y="3" width="7" height="9" rx="1"/><rect x="14" y="3" width="7" height="5" rx="1"/><rect x="14" y="12" width="7" height="9" rx="1"/><rect x="3" y="16" width="7" height="5" rx="1"/>',
    store: '<path d="m3 9 9-7 9 7v11a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2Z"/><path d="M9 22V12h6v10"/>',
    chat: '<path d="M7.9 20A9 9 0 1 0 4 16.1L2 22Z"/>',
    mail: '<rect x="2" y="4" width="20" height="16" rx="2"/><path d="m22 7-10 6L2 7"/>',
  };

  function icon(name, size = 20) {
    const s = document.createElementNS('http://www.w3.org/2000/svg', 'svg');
    s.setAttribute('viewBox', '0 0 24 24');
    s.setAttribute('width', size);
    s.setAttribute('height', size);
    s.setAttribute('fill', 'none');
    s.setAttribute('stroke', 'currentColor');
    s.setAttribute('stroke-width', '2');
    s.setAttribute('stroke-linecap', 'round');
    s.setAttribute('stroke-linejoin', 'round');
    s.setAttribute('aria-hidden', 'true');
    s.innerHTML = ICONS[name]; // نصوص ثابتة من الكود فقط
    return s;
  }

  function applyIcons(root = document) {
    $$('[data-icon]', root).forEach((el) => {
      el.prepend(icon(el.dataset.icon, Number(el.dataset.size) || 20));
      el.removeAttribute('data-icon');
    });
  }

  function money(price, currency) {
    const s = Number(price).toLocaleString('en-US', { maximumFractionDigits: 2 });
    return currency === 'USD' ? `$${s}` : `${s} دج`;
  }

  function toast(message, type = '') {
    const t = h('div', { class: `toast ${type}`, role: 'status' }, message);
    $('#toasts').append(t);
    setTimeout(() => t.remove(), 3800);
  }

  const state = { user: null, csrf: '', kind: '', category: '' };

  async function api(path, { method = 'GET', body, form } = {}) {
    const headers = {};
    let payload;
    if (form) payload = form;
    else if (body !== undefined) {
      headers['Content-Type'] = 'application/json';
      payload = JSON.stringify(body);
    }
    if (method !== 'GET') headers['X-CSRF-Token'] = state.csrf;
    let res;
    try {
      res = await fetch(path, { method, headers, body: payload, credentials: 'same-origin' });
    } catch {
      throw new Error('تعذّر الاتصال بالخادم، تحقق من الإنترنت');
    }
    let data = null;
    try { data = await res.json(); } catch { /* ليس JSON */ }
    if (!res.ok) {
      if (res.status === 401 && state.user) { sessionExpired(); }
      const err = new Error((data && data.error) || 'حدث خطأ غير متوقع');
      err.status = res.status;
      throw err;
    }
    return data;
  }

  // ───────────── الشاشات الرئيسية ─────────────
  let authSwitch = null;

  function showAuth() {
    closeModal();
    if (authSwitch) authSwitch('login');
    $('#app-view').hidden = true;
    $('#auth-view').hidden = false;
    document.body.classList.remove('no-scroll');
  }

  function sessionExpired() {
    state.user = null;
    showAuth();
    toast('انتهت الجلسة، سجّل الدخول من جديد', 'error');
  }

  function enterApp() {
    $('#auth-view').hidden = true;
    $('#app-view').hidden = false;
    $('#user-chip').textContent = state.user.username;
    state.kind = '';
    state.category = '';
    $$('#kind-filter .seg').forEach((b) => b.classList.toggle('is-active', b.dataset.kind === ''));
    showView('feed');
    loadFeed(true);
  }

  function showView(view) {
    const isAdmin = state.user && state.user.role === 'admin';
    $('#feed-view').hidden = view !== 'feed';
    $('#admin-view').hidden = view !== 'admin';
    $('#btn-admin').hidden = !(isAdmin && view === 'feed');
    $('#btn-store').hidden = !(isAdmin && view === 'admin');
    window.scrollTo(0, 0);
  }

  // ───────────── الدخول وإنشاء الحساب ─────────────
  function setupAuth() {
    const tabs = { login: $('#tab-login'), register: $('#tab-register') };
    const forms = { login: $('#form-login'), register: $('#form-register') };
    const switchTo = (name) => {
      for (const k of Object.keys(tabs)) {
        tabs[k].classList.toggle('is-active', k === name);
        tabs[k].setAttribute('aria-selected', String(k === name));
        forms[k].hidden = k !== name;
        $('.form-error', forms[k]).hidden = true;
      }
    };
    authSwitch = switchTo;
    tabs.login.addEventListener('click', () => switchTo('login'));
    tabs.register.addEventListener('click', () => switchTo('register'));

    $$('.pw-toggle').forEach((btn) => {
      btn.addEventListener('click', () => {
        const input = $('input', btn.parentElement);
        const show = input.type === 'password';
        input.type = show ? 'text' : 'password';
        btn.replaceChildren(icon(show ? 'eyeOff' : 'eye'));
        btn.setAttribute('aria-label', show ? 'إخفاء كلمة المرور' : 'إظهار كلمة المرور');
      });
    });

    const submit = async (form, url, build) => {
      const err = $('.form-error', form);
      const btn = $('button[type=submit]', form);
      err.hidden = true;
      let payload;
      try { payload = build(new FormData(form)); } catch (e) { err.textContent = e.message; err.hidden = false; return; }
      btn.disabled = true;
      try {
        const data = await api(url, { method: 'POST', body: payload });
        state.csrf = data.csrf;
        state.user = data.user;
        form.reset();
        enterApp();
      } catch (e) {
        err.textContent = e.message;
        err.hidden = false;
      } finally {
        btn.disabled = false;
      }
    };

    forms.login.addEventListener('submit', (e) => {
      e.preventDefault();
      submit(forms.login, '/api/login', (fd) => {
        const username = fd.get('username').trim();
        const password = fd.get('password');
        if (!username || !password) throw new Error('أدخل اسم المستخدم وكلمة المرور');
        return { username, password };
      });
    });

    forms.register.addEventListener('submit', (e) => {
      e.preventDefault();
      submit(forms.register, '/api/register', (fd) => {
        const username = fd.get('username').trim();
        const phone = fd.get('phone').replace(/[\s\-().]/g, '');
        const password = fd.get('password');
        if (!/^[\p{L}\p{N}_.\-]{3,24}$/u.test(username)) throw new Error('اسم المستخدم: حروف وأرقام ونقطة وشرطة فقط، من 3 إلى 24 حرفًا');
        if (!/^\+?\d{8,15}$/.test(phone)) throw new Error('رقم الهاتف غير صالح (أرقام فقط)');
        if (password.length < 8) throw new Error('كلمة المرور يجب أن تكون 8 أحرف على الأقل');
        return { username, phone, password };
      });
    });
  }

  // ───────────── المتجر: الفلاتر والسكرول اللانهائي ─────────────
  const feed = { before: null, hasMore: true, loading: false, token: 0, count: 0 };

  function renderChips(categories) {
    const box = $('#category-chips');
    box.replaceChildren();
    if (!categories.length) return;
    const make = (label, value) =>
      h('button', {
        type: 'button',
        class: `chip${state.category === value ? ' is-active' : ''}`,
        'aria-pressed': String(state.category === value),
        onclick: () => { state.category = value; loadFeed(true); },
      }, label);
    box.append(make('كل الألعاب', ''), ...categories.map((c) => make(c, c)));
  }

  function productCard(p) {
    const open = () => openProduct(p);
    const extra = p.images.length;
    return h('article', { class: 'card' },
      h('button', { type: 'button', class: 'card-media', onclick: open, 'aria-label': `تفاصيل ${p.name}` },
        h('img', { src: p.main_image, alt: '', loading: 'lazy', decoding: 'async' }),
        h('span', { class: 'badge' }, p.kind === 'topup' ? 'شحن' : 'حساب'),
        extra ? h('span', { class: 'badge badge-count' }, `+${extra} صور`) : null,
        h('span', { class: 'price-tag' }, money(p.price, p.currency)),
      ),
      h('div', { class: 'card-body' },
        p.category ? h('span', { class: 'card-game' }, p.category) : null,
        h('h3', { class: 'card-title' }, p.name),
        p.notes ? h('p', { class: 'card-notes' }, p.notes) : null,
        h('button', { type: 'button', class: 'btn btn-primary btn-block', onclick: open }, 'اشتري الآن'),
      ),
    );
  }

  async function loadFeed(reset = false) {
    if (feed.loading && !reset) return;
    const box = $('#feed');
    const status = $('#feed-status');
    if (reset) {
      feed.before = null;
      feed.hasMore = true;
      feed.count = 0;
      feed.token++;
      box.replaceChildren(h('div', { class: 'skeleton' }), h('div', { class: 'skeleton' }));
      status.textContent = '';
    }
    if (!feed.hasMore) return;
    const token = feed.token;
    feed.loading = true;
    try {
      const q = new URLSearchParams({ limit: '8' });
      if (feed.before) q.set('before', feed.before);
      if (state.kind) q.set('kind', state.kind);
      if (state.category) q.set('category', state.category);
      const data = await api(`/api/products?${q}`);
      if (token !== feed.token) return;
      if (reset) {
        box.replaceChildren();
        if (state.category && !data.categories.includes(state.category)) state.category = '';
        renderChips(data.categories);
      }
      box.append(...data.items.map(productCard));
      feed.count += data.items.length;
      feed.before = data.next_before;
      feed.hasMore = data.has_more;
      if (!feed.count) {
        box.replaceChildren(h('div', { class: 'empty' },
          h('strong', null, 'لا توجد منتجات هنا بعد'),
          'جرّب نوعًا آخر أو عُد لاحقًا.'));
      }
      status.textContent = !feed.hasMore && feed.count > 4 ? 'وصلت إلى آخر المنتجات' : '';
    } catch (e) {
      if (token !== feed.token) return;
      if (reset) box.replaceChildren();
      status.replaceChildren(
        h('p', null, e.message),
        h('button', { type: 'button', class: 'btn btn-outline btn-sm', onclick: () => loadFeed(reset && !feed.count) }, 'إعادة المحاولة'));
    } finally {
      if (token === feed.token) {
        feed.loading = false;
        // إن بقي الحارس ظاهرًا بعد التحميل نعيد المراقبة لتحميل الصفحة التالية
        if (feed.hasMore && observer) { observer.unobserve(sentinel); observer.observe(sentinel); }
      }
    }
  }

  const sentinel = $('#feed-sentinel');
  const observer = 'IntersectionObserver' in window
    ? new IntersectionObserver((entries) => {
        if (entries.some((e) => e.isIntersecting) && !$('#feed-view').hidden && state.user) loadFeed(false);
      }, { rootMargin: '700px 0px' })
    : null;
  if (observer) observer.observe(sentinel);

  function setupFilters() {
    $('#kind-filter').addEventListener('click', (e) => {
      const btn = e.target.closest('.seg');
      if (!btn) return;
      state.kind = btn.dataset.kind;
      state.category = '';
      $$('#kind-filter .seg').forEach((b) => b.classList.toggle('is-active', b === btn));
      loadFeed(true);
    });
  }

  // ───────────── النافذة: تفاصيل المنتج والطلب ─────────────
  let lastFocus = null;
  let escHandler = null;

  function closeModal() {
    const root = $('#modal-root');
    if (!root.firstChild) return;
    root.replaceChildren();
    document.body.classList.remove('no-scroll');
    if (escHandler) { document.removeEventListener('keydown', escHandler); escHandler = null; }
    if (lastFocus && document.contains(lastFocus)) lastFocus.focus();
  }

  function mountModal(sheetChildren, labelledBy) {
    closeModal();
    lastFocus = document.activeElement;
    const closeBtn = h('button', { type: 'button', class: 'sheet-close', 'aria-label': 'إغلاق', onclick: closeModal });
    closeBtn.append(icon('close'));
    const sheet = h('div', { class: 'sheet', role: 'dialog', 'aria-modal': 'true', 'aria-labelledby': labelledBy }, closeBtn, sheetChildren);
    const overlay = h('div', { class: 'overlay', onclick: (e) => { if (e.target === overlay) closeModal(); } }, sheet);
    $('#modal-root').append(overlay);
    document.body.classList.add('no-scroll');
    escHandler = (e) => { if (e.key === 'Escape') closeModal(); };
    document.addEventListener('keydown', escHandler);
    closeBtn.focus();
    return { sheet, overlay };
  }

  function buildGallery(p) {
    const imgs = [p.main_image, ...p.images];
    let idx = 0;
    const main = h('img', { class: 'gallery-main', src: imgs[0], alt: p.name });
    const wrap = h('div', { class: 'gallery' }, main);
    if (imgs.length === 1) return { el: wrap, next() {}, prev() {} };

    const thumbs = imgs.map((src, i) => {
      const b = h('button', { type: 'button', class: 'thumb', 'aria-label': `الصورة ${i + 1}`, onclick: () => go(i) }, h('img', { src, alt: '', loading: 'lazy' }));
      return b;
    });
    const go = (i) => {
      idx = (i + imgs.length) % imgs.length;
      main.src = imgs[idx];
      thumbs.forEach((t, j) => t.classList.toggle('is-active', j === idx));
      thumbs[idx].scrollIntoView({ block: 'nearest', inline: 'nearest' });
    };
    const prev = h('button', { type: 'button', class: 'gallery-nav prev', 'aria-label': 'الصورة السابقة', onclick: () => go(idx - 1) });
    prev.append(icon('chevR'));
    const next = h('button', { type: 'button', class: 'gallery-nav next', 'aria-label': 'الصورة التالية', onclick: () => go(idx + 1) });
    next.append(icon('chevL'));
    wrap.append(prev, next);
    const strip = h('div', { class: 'thumbs' }, thumbs);
    go(0);
    return { el: h('div', null, wrap, strip), next: () => go(idx + 1), prev: () => go(idx - 1) };
  }

  function openProduct(p) {
    const gallery = buildGallery(p);
    const orderBox = h('div', { class: 'detail' });
    const detail = h('div', { class: 'detail' },
      h('div', { class: 'detail-top' },
        h('span', { class: 'pill' }, [p.kind === 'topup' ? 'شحن' : 'حساب', p.category].filter(Boolean).join(' — ')),
        h('span', { class: 'detail-price' }, money(p.price, p.currency))),
      h('h2', { id: 'm-title' }, p.name),
      p.notes ? h('p', { class: 'notes-box' }, p.notes) : null,
    );
    const { overlay } = mountModal([gallery.el, detail, orderBox], 'm-title');
    detail.style.paddingBottom = '0';
    orderBox.style.paddingTop = '.5rem';

    const keyNav = (e) => {
      if (e.key === 'ArrowLeft') gallery.next();
      if (e.key === 'ArrowRight') gallery.prev();
    };
    document.addEventListener('keydown', keyNav);
    new MutationObserver((_, mo) => { if (!overlay.isConnected) { document.removeEventListener('keydown', keyNav); mo.disconnect(); } })
      .observe($('#modal-root'), { childList: true });

    const showCta = () => {
      orderBox.replaceChildren(
        h('button', { type: 'button', class: 'btn btn-primary btn-block', onclick: showForm }, 'اطلب الآن'),
        h('p', { class: 'hint' }, 'لا يوجد دفع إلكتروني على الموقع. نتواصل معك ونُكمل الدفع يدويًا.'));
    };

    const showForm = () => {
      const nameIn = h('input', { name: 'name', type: 'text', required: true, maxlength: '60', autocomplete: 'name', value: state.user.username });
      const contactIn = h('input', { name: 'contact', type: 'tel', inputmode: 'tel', required: true, maxlength: '254', autocomplete: 'tel', value: state.user.phone || '' });
      const contactLabel = h('span', null, 'رقم الواتساب');
      const radio = (value, label, checked) =>
        h('label', null, h('input', { type: 'radio', name: 'ct', value, checked }), label);
      const waRadio = radio('whatsapp', 'واتساب', true);
      const mailRadio = radio('email', 'بريد إلكتروني', false);
      const err = h('p', { class: 'form-error', role: 'alert', hidden: true });
      const submit = h('button', { type: 'submit', class: 'btn btn-primary btn-block' }, 'تأكيد الطلب');
      const form = h('form', { class: 'form', novalidate: true },
        h('label', { class: 'field' }, h('span', null, 'الاسم'), nameIn),
        h('div', { class: 'field' }, h('span', null, 'طريقة التواصل'), h('div', { class: 'seg-row' }, waRadio, mailRadio)),
        h('label', { class: 'field' }, contactLabel, contactIn),
        err, submit,
        h('button', { type: 'button', class: 'btn btn-outline btn-block', onclick: showCta }, 'رجوع'));
      orderBox.replaceChildren(form);
      nameIn.focus();

      const ctype = () => $('input[name=ct]:checked', form).value;
      form.addEventListener('change', (e) => {
        if (e.target.name !== 'ct') return;
        if (ctype() === 'email') {
          contactLabel.textContent = 'البريد الإلكتروني';
          contactIn.type = 'email'; contactIn.inputMode = 'email'; contactIn.autocomplete = 'email'; contactIn.value = '';
        } else {
          contactLabel.textContent = 'رقم الواتساب';
          contactIn.type = 'tel'; contactIn.inputMode = 'tel'; contactIn.autocomplete = 'tel'; contactIn.value = state.user.phone || '';
        }
      });

      form.addEventListener('submit', async (e) => {
        e.preventDefault();
        err.hidden = true;
        const name = nameIn.value.trim();
        let contact = contactIn.value.trim();
        const type = ctype();
        let problem = '';
        if (name.length < 2) problem = 'اكتب اسمك (حرفان على الأقل)';
        else if (type === 'whatsapp') {
          contact = contact.replace(/[\s\-().]/g, '');
          if (!/^\+?\d{8,15}$/.test(contact)) problem = 'رقم الواتساب غير صالح (أرقام فقط)';
        } else if (!/^[A-Za-z0-9._%+\-]{1,64}@[A-Za-z0-9.\-]{1,190}\.[A-Za-z]{2,}$/.test(contact)) {
          problem = 'البريد الإلكتروني غير صالح';
        }
        if (problem) { err.textContent = problem; err.hidden = false; return; }
        submit.disabled = true;
        try {
          const res = await api('/api/orders', { method: 'POST', body: { product_id: p.id, name, contact_type: type, contact } });
          showSuccess(res);
        } catch (ex) {
          err.textContent = ex.message; err.hidden = false; submit.disabled = false;
        }
      });
    };

    const showSuccess = (res) => {
      const mark = h('span', { class: 'success-mark' });
      mark.append(icon('check', 34));
      orderBox.replaceChildren(h('div', { class: 'success' },
        mark,
        h('h3', null, 'تم استلام طلبك'),
        h('p', null, res.message),
        h('p', { class: 'hint' }, `رقم الطلب: ${res.order_id}`),
        h('button', { type: 'button', class: 'btn btn-primary btn-block', onclick: closeModal }, 'تابع التصفح')));
    };

    showCta();
  }

  // ───────────── لوحة الأدمن ─────────────
  const STATUS_LABELS = { new: 'جديد', contacted: 'تم التواصل', completed: 'مكتمل', cancelled: 'ملغي' };
  const admin = { tab: 'today', status: '', editing: null, categories: [], list: { before: null, hasMore: false } };

  async function refreshStats() {
    try {
      const s = await api('/api/admin/stats');
      const stat = (n, label, hot) => h('div', { class: `stat${hot ? ' is-hot' : ''}` }, h('b', null, n), h('span', null, label));
      $('#admin-stats').replaceChildren(
        stat(s.today_orders, 'طلبات اليوم'),
        stat(s.new_orders, 'جديدة بانتظار الرد', s.new_orders > 0),
        stat(s.products_active, s.products_total > s.products_active ? `منتجات ظاهرة (${s.products_total - s.products_active} مخفي)` : 'منتجات ظاهرة'));
    } catch (e) { toast(e.message, 'error'); }
  }

  function setTab(tab) {
    admin.tab = tab;
    $$('#admin-tabs .tab').forEach((b) => {
      const on = b.dataset.tab === tab;
      b.classList.toggle('is-active', on);
      b.setAttribute('aria-selected', String(on));
    });
    $('#admin-tabs [data-tab=form]').textContent = admin.editing && tab === 'form' ? 'تعديل منتج' : 'إضافة منتج';
    const panel = $('#admin-panel');
    panel.replaceChildren();
    if (tab === 'today' || tab === 'all') renderOrders(panel);
    else if (tab === 'products') renderProducts(panel);
    else renderProductForm(panel);
  }

  async function openAdmin() {
    showView('admin');
    refreshStats();
    setTab(admin.tab);
  }

  function loadMoreButton(onClick) {
    return h('button', { type: 'button', class: 'btn btn-outline btn-block', onclick: (e) => { e.currentTarget.remove(); onClick(); } }, 'تحميل المزيد');
  }

  // ----- الطلبات -----
  function renderOrders(panel) {
    const scope = admin.tab;
    const list = h('div', { class: 'list' });
    const more = h('div');
    const select = h('select', { 'aria-label': 'تصفية حسب الحالة', onchange: (e) => { admin.status = e.target.value; setTab(admin.tab); } },
      h('option', { value: '' }, 'كل الحالات'),
      ...Object.entries(STATUS_LABELS).map(([v, l]) => h('option', { value: v, selected: admin.status === v }, l)));
    const refresh = h('button', { type: 'button', class: 'btn btn-outline btn-sm', onclick: () => { refreshStats(); setTab(admin.tab); } }, 'تحديث');
    panel.append(h('div', { class: 'toolbar' }, select, refresh), list, more);

    const load = async (before) => {
      try {
        const q = new URLSearchParams({ scope });
        if (admin.status) q.set('status', admin.status);
        if (before) q.set('before', before);
        const data = await api(`/api/admin/orders?${q}`);
        if (!before && !data.items.length) {
          list.replaceChildren(h('div', { class: 'empty' },
            h('strong', null, scope === 'today' ? 'لا توجد طلبات اليوم بعد' : 'لا توجد طلبات'),
            'ستظهر الطلبات هنا فور وصولها.'));
        }
        list.append(...data.items.map(orderRow));
        more.replaceChildren();
        if (data.has_more) more.append(loadMoreButton(() => load(data.next_before)));
      } catch (e) { toast(e.message, 'error'); }
    };
    load(null);
  }

  function orderRow(o) {
    const row = h('article', { class: `row status-${o.status}` });
    const contactBtn = o.contact_type === 'whatsapp' && o.wa_link
      ? h('a', { class: 'btn btn-wa btn-sm', href: o.wa_link, target: '_blank', rel: 'noopener noreferrer' }, icon('chat', 16), 'فتح الواتساب')
      : h('a', { class: 'btn btn-outline btn-sm', href: `mailto:${o.contact}` }, icon('mail', 16), 'إرسال بريد');
    const select = h('select', {
      'aria-label': 'حالة الطلب',
      onchange: async (e) => {
        const next = e.target.value;
        const prev = [...row.classList].find((c) => c.startsWith('status-'));
        try {
          await api(`/api/admin/orders/${o.id}/status`, { method: 'POST', body: { status: next } });
          row.classList.remove(prev);
          row.classList.add(`status-${next}`);
          refreshStats();
          toast('تم تحديث الحالة', 'ok');
        } catch (ex) {
          e.target.value = prev.replace('status-', '');
          toast(ex.message, 'error');
        }
      },
    }, ...Object.entries(STATUS_LABELS).map(([v, l]) => h('option', { value: v, selected: o.status === v }, l)));
    row.append(
      h('div', { class: 'row-head' },
        h('span', { class: 'row-title' }, `#${o.id} ${o.product_name}`),
        h('span', { class: 'row-meta' }, o.created_at)),
      h('div', null, o.buyer_name, ' — ', h('bdi', { dir: 'ltr' }, o.contact)),
      h('div', { class: 'row-meta meta-flex' }, h('span', null, `السعر: ${money(o.price, o.currency)}`), o.username ? h('span', null, `الحساب: ${o.username}`) : null),
      h('div', { class: 'row-actions' }, contactBtn, select));
    return row;
  }

  // ----- المنتجات -----
  function renderProducts(panel) {
    const list = h('div', { class: 'list' });
    const more = h('div');
    panel.append(list, more);
    const load = async (before) => {
      try {
        const q = new URLSearchParams();
        if (before) q.set('before', before);
        const data = await api(`/api/admin/products?${q}`);
        admin.categories = data.categories;
        if (!before && !data.items.length) {
          list.replaceChildren(h('div', { class: 'empty' }, h('strong', null, 'لا توجد منتجات'), 'أضف أول منتج من تبويب «إضافة منتج».'));
        }
        list.append(...data.items.map(productRow));
        more.replaceChildren();
        if (data.has_more) more.append(loadMoreButton(() => load(data.next_before)));
      } catch (e) { toast(e.message, 'error'); }
    };
    load(null);
  }

  function productRow(p) {
    const row = h('article', { class: 'row' });
    const tag = h('span', { class: `tag${p.is_active ? '' : ' tag-off'}` }, p.is_active ? 'ظاهر' : 'مخفي');
    const toggle = h('button', {
      type: 'button', class: 'btn btn-outline btn-sm',
      onclick: async () => {
        try {
          const r = await api(`/api/admin/products/${p.id}/visibility`, { method: 'POST', body: { active: !p.is_active } });
          p.is_active = r.is_active;
          tag.textContent = p.is_active ? 'ظاهر' : 'مخفي';
          tag.classList.toggle('tag-off', !p.is_active);
          toggle.textContent = p.is_active ? 'إخفاء' : 'إظهار';
          refreshStats();
        } catch (e) { toast(e.message, 'error'); }
      },
    }, p.is_active ? 'إخفاء' : 'إظهار');
    const edit = h('button', { type: 'button', class: 'btn btn-outline btn-sm', onclick: () => { admin.editing = p; setTab('form'); } }, icon('edit', 16), 'تعديل');
    const del = h('button', {
      type: 'button', class: 'btn btn-danger btn-sm',
      onclick: async () => {
        if (!confirm(`حذف «${p.name}» نهائيًا؟ الطلبات السابقة تبقى محفوظة.`)) return;
        try {
          await api(`/api/admin/products/${p.id}`, { method: 'DELETE' });
          row.remove();
          refreshStats();
          toast('تم حذف المنتج', 'ok');
        } catch (e) { toast(e.message, 'error'); }
      },
    }, icon('trash', 16), 'حذف');
    row.append(
      h('div', { class: 'prow' },
        h('img', { src: p.main_image, alt: '', loading: 'lazy' }),
        h('div', null,
          h('div', { class: 'row-title' }, p.name),
          h('div', { class: 'row-meta meta-flex' }, h('span', null, p.kind === 'topup' ? 'شحن' : 'حساب'), p.category ? h('span', null, p.category) : null, h('span', null, money(p.price, p.currency)), tag))),
      h('div', { class: 'row-actions' }, edit, toggle, del));
    return row;
  }

  // ----- نموذج المنتج (إضافة / تعديل) -----
  async function prepareImage(file) {
    if (!file.type.startsWith('image/') || file.type === 'image/gif') return file;
    try {
      const bmp = await createImageBitmap(file);
      const scale = Math.min(1, 1600 / Math.max(bmp.width, bmp.height));
      if (scale === 1 && file.size < 900 * 1024) return file;
      const canvas = document.createElement('canvas');
      canvas.width = Math.round(bmp.width * scale);
      canvas.height = Math.round(bmp.height * scale);
      const ctx = canvas.getContext('2d');
      ctx.fillStyle = '#fff';
      ctx.fillRect(0, 0, canvas.width, canvas.height);
      ctx.drawImage(bmp, 0, 0, canvas.width, canvas.height);
      const blob = await new Promise((r) => canvas.toBlob(r, 'image/jpeg', 0.86));
      if (!blob || blob.size >= file.size) return file;
      return new File([blob], file.name.replace(/\.\w+$/, '') + '.jpg', { type: 'image/jpeg' });
    } catch {
      return file;
    }
  }

  async function renderProductForm(panel) {
    const editing = admin.editing;
    if (!admin.categories.length) {
      try { admin.categories = (await api('/api/admin/products?limit=1')).categories; } catch { /* اختياري */ }
    }
    if (admin.tab !== 'form') return;
    const suggestions = [...new Set(['PUBG Mobile', 'Free Fire', 'eFootball', ...admin.categories])];

    let mainFile = null;
    let extraFiles = [];
    const removed = new Set();
    const existing = editing ? editing.images : [];

    const f = (name, label, el, hint) => h('label', { class: 'field' }, h('span', null, label), el, hint ? h('small', null, hint) : null);
    const nameIn = h('input', { name: 'name', required: true, maxlength: '80', value: editing ? editing.name : '' });
    const kindIn = h('select', { name: 'kind' },
      h('option', { value: 'account', selected: !editing || editing.kind === 'account' }, 'حساب لعبة'),
      h('option', { value: 'topup', selected: editing && editing.kind === 'topup' }, 'شحن (شدات / جواهر / عملات)'));
    const catIn = h('input', { name: 'category', maxlength: '40', list: 'cat-list', value: editing ? editing.category : '', placeholder: 'مثال: PUBG Mobile' });
    const catList = h('datalist', { id: 'cat-list' }, suggestions.map((s) => h('option', { value: s })));
    const priceIn = h('input', { name: 'price', type: 'text', inputmode: 'decimal', required: true, value: editing ? String(editing.price) : '' });
    const curIn = h('select', { name: 'currency' },
      h('option', { value: 'DZD', selected: !editing || editing.currency === 'DZD' }, 'دينار جزائري (دج)'),
      h('option', { value: 'USD', selected: editing && editing.currency === 'USD' }, 'دولار ($)'));
    const notesIn = h('textarea', { name: 'notes', maxlength: '3000', placeholder: 'المستوى، الرتبة، ما يتضمنه الحساب، طريقة التسليم…' }, editing ? editing.notes : '');
    const mainPrev = h('div', { class: 'previews' });
    const extraPrev = h('div', { class: 'previews' });
    const mainIn = h('input', { type: 'file', accept: 'image/*' });
    const extraIn = h('input', { type: 'file', accept: 'image/*', multiple: true });
    const err = h('p', { class: 'form-error', role: 'alert', hidden: true });
    const submit = h('button', { type: 'submit', class: 'btn btn-primary' }, editing ? 'حفظ التعديلات' : 'نشر المنتج');

    const thumb = (src, onRemove, extraClass = '') => {
      const b = h('button', { type: 'button', 'aria-label': 'إزالة الصورة', onclick: onRemove });
      b.append(icon('close', 14));
      return h('div', { class: `preview ${extraClass}` }, h('img', { src, alt: '' }), b);
    };
    const drawMain = () => {
      mainPrev.replaceChildren();
      if (mainFile) mainPrev.append(thumb(URL.createObjectURL(mainFile), () => { mainFile = null; drawMain(); }));
      else if (editing) mainPrev.append(h('div', { class: 'preview' }, h('img', { src: editing.main_image, alt: '' })));
    };
    const drawExtras = () => {
      extraPrev.replaceChildren(
        ...existing.map((im) => thumb(im.url, () => { removed.has(im.id) ? removed.delete(im.id) : removed.add(im.id); drawExtras(); }, removed.has(im.id) ? 'is-removed' : '')),
        ...extraFiles.map((file, i) => thumb(URL.createObjectURL(file), () => { extraFiles.splice(i, 1); drawExtras(); })));
    };
    mainIn.addEventListener('change', async () => {
      if (mainIn.files[0]) { mainFile = await prepareImage(mainIn.files[0]); drawMain(); }
      mainIn.value = '';
    });
    extraIn.addEventListener('change', async () => {
      const picked = await Promise.all([...extraIn.files].map(prepareImage));
      extraFiles.push(...picked);
      extraIn.value = '';
      drawExtras();
    });
    drawMain(); drawExtras();

    const form = h('form', { class: 'form form-card', novalidate: true },
      f('name', 'اسم المنتج', nameIn),
      h('div', { class: 'grid-2' }, f('kind', 'النوع', kindIn), f('category', 'اللعبة', catIn)),
      catList,
      h('div', { class: 'grid-2' }, f('price', 'السعر', priceIn), f('currency', 'العملة', curIn)),
      f('main', 'الصورة الرئيسية (تظهر في الصفحة الرئيسية)', mainIn, editing ? 'اتركها فارغة للإبقاء على الصورة الحالية.' : 'مطلوبة.'),
      mainPrev,
      f('extra', 'صور إضافية (تظهر عند فتح المنتج)', extraIn, 'حتى 10 صور. تُصغَّر تلقائيًا قبل الرفع.'),
      extraPrev,
      f('notes', 'ملاحظات', notesIn),
      err,
      h('div', { class: 'row-actions' }, submit,
        editing ? h('button', { type: 'button', class: 'btn btn-outline', onclick: () => { admin.editing = null; setTab('products'); } }, 'إلغاء') : null));

    form.addEventListener('submit', async (e) => {
      e.preventDefault();
      err.hidden = true;
      const price = priceIn.value.trim().replace(',', '.');
      let problem = '';
      if (nameIn.value.trim().length < 2) problem = 'اكتب اسم المنتج';
      else if (!(Number(price) > 0)) problem = 'السعر غير صالح';
      else if (!editing && !mainFile) problem = 'اختر الصورة الرئيسية';
      else if (existing.length - removed.size + extraFiles.length > 10) problem = 'الحد الأقصى 10 صور إضافية';
      if (problem) { err.textContent = problem; err.hidden = false; return; }

      const fd = new FormData();
      fd.append('name', nameIn.value.trim());
      fd.append('kind', kindIn.value);
      fd.append('category', catIn.value.trim());
      fd.append('price', price);
      fd.append('currency', curIn.value);
      fd.append('notes', notesIn.value.trim());
      if (mainFile) fd.append('main_image', mainFile, mainFile.name);
      extraFiles.forEach((file) => fd.append('images', file, file.name));
      removed.forEach((id) => fd.append('remove_images', id));

      submit.disabled = true;
      submit.textContent = 'جارٍ الرفع…';
      try {
        await api(editing ? `/api/admin/products/${editing.id}` : '/api/admin/products', { method: editing ? 'PUT' : 'POST', form: fd });
        toast(editing ? 'تم حفظ التعديلات' : 'تم نشر المنتج', 'ok');
        admin.editing = null;
        admin.categories = [];
        refreshStats();
        setTab('products');
      } catch (ex) {
        err.textContent = ex.message; err.hidden = false;
        submit.disabled = false;
        submit.textContent = editing ? 'حفظ التعديلات' : 'نشر المنتج';
      }
    });
    panel.replaceChildren(form);
  }

  // ───────────── التهيئة ─────────────
  async function boot() {
    applyIcons();
    setupAuth();
    setupFilters();

    $('#btn-logout').addEventListener('click', async () => {
      try {
        const data = await api('/api/logout', { method: 'POST' });
        state.csrf = data.csrf;
      } catch { /* نكمل الخروج محليًا */ }
      state.user = null;
      admin.editing = null; admin.categories = [];
      showAuth();
    });
    $('#btn-admin').addEventListener('click', openAdmin);
    $('#btn-store').addEventListener('click', () => { showView('feed'); });
    $('#brand-home').addEventListener('click', (e) => { e.preventDefault(); if (state.user) { showView('feed'); window.scrollTo(0, 0); } });
    $('#admin-tabs').addEventListener('click', (e) => {
      const btn = e.target.closest('.tab');
      if (!btn) return;
      if (btn.dataset.tab === 'form' && admin.tab !== 'form') admin.editing = null;
      setTab(btn.dataset.tab);
    });

    try {
      const me = await api('/api/me');
      state.csrf = me.csrf;
      state.user = me.user;
      const name = (me.store && me.store.name) || 'متجر الألعاب';
      document.title = name;
      $$('[data-store-name]').forEach((el) => { el.textContent = name; });
    } catch (e) {
      toast(e.message, 'error');
    }
    $('#boot').remove();
    if (state.user) enterApp(); else showAuth();
  }

  boot();
})();
